package app;
import utils.Lista;

public class Main
{
    public void main(String[] args)
    {
        Lista<Integer> lista = new Lista<>();
        
        lista.append(10);
        lista.append(11);
        lista.append(12);
        lista.append(13);
        lista.append(14);
        lista.append(15);
        lista.append(16);
        lista.append(17);
        lista.append(18);
        lista.append(19);

        lista.eliminar(0);
        lista.eliminar(8);
        lista.eliminar(3);
        lista.eliminar(90);

        lista.mostrar();

    }
}
