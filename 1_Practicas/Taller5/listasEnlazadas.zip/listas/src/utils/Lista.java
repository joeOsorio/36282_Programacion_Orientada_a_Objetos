package utils;
import utils.Nodo;
public class Lista<V>
{
    private Nodo<V> head;
    private Nodo<V> tail;
    private int size;
    public Lista()
    {
        head = null;
        tail = null;
    }
    public void append(V valor)
    {
        Nodo<V> nuevo = new Nodo<>(valor);
        if (head == null)
        {
            head = nuevo;
        }
        else
        {
            nuevo.prev = tail;
            tail.sig = nuevo;
        }
        tail = nuevo;
        size++;
    }
    public void eliminar(int id)
    {
        if(id >= size) return;
        if(id == 0)
        {
            head = head.sig;
            head.prev = null;
            size--;
            return;
        }
        else if(id == size-1)
        {
            tail = tail.prev;
            tail.sig = null;
            size--;
            return;
        }
        //buscar el iD
        Nodo<V> actual = head;
        for(int i=0;i<id;i++)
            actual = actual.sig;
        actual.prev.sig = actual.sig;
        actual.sig.prev = actual.prev;
        actual = null;
        size--;
    }
    public void mostrar()
    {
        for(var n=head;n!=null;n=n.sig)
        {
            var valorP = (n.prev==null) ? "null" :n.prev.valor;
            var valorS = (n.sig==null) ? "null" :n.sig.valor;
            System.out.println("["+valorP+"] <"+n.valor+">["+valorS+"]");
        }
    }
}

