package utils;
public class Nodo<T>
{
    public T valor;
    public Nodo<T> sig;
    public Nodo<T> prev;

    public Nodo(T valor)
    {
        this.valor = valor;
        sig = null;
        prev = null;
    }
}
